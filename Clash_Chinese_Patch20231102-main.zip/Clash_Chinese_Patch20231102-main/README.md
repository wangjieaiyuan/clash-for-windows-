# Clash_Chinese_Patch

[![](https://img.shields.io/badge/Telegram-公告板-blue)](https://t.me/ClashR_for_Windows_Channel)
[![](https://img.shields.io/badge/Telegram-交流群-purple)](https://t.me/+Se4RSc06w8QK1HiS)

## 解释说明

此版本为[Clash for Windows](https://github.com/Fndroid/clash_for_windows_pkg/releases)原版汉化页面。

⚠️汉化永久免费，请注意欺诈！！！

## 使用方法

请自行替换下列路径中的app.asar文件

`Clash for Windows\resources\app.asar`

---

居然有人以为下载了就能直接用的😅，还是放两个我自己用的机场吧

还算便宜且比较稳定（建议按月充值，以免跑路）：[星链计划](https://starlink.to/#/register?code=ZGpZxxUy)

按量计费特别便宜但不太稳定（充10块钱够用好久了）：[Taffy Cloud](https://taffy.cloud/#/login?type=reg&affcode=1lJZlvoC)

---

软件仅供学习，24小时内删除。
